# TASKS.md — customer platform build plan

Status keys: `[ ]` todo · `[~]` in progress · `[x]` done · `[!]` blocked.
Every task has an ID. Use it in branch names (`t2-04-availability-engine`) and commit messages.
Specs: CONTROL_FLOW_AND_DATA_LOGIC.md (CF §n) and DESIGN.md (DS §n).
Gates: CHECKPOINTS.md (CP n).

Key dates (2026): Dussehra 20 Oct · Karva Chauth 29 Oct · Dhanteras 6 Nov · Diwali 8 Nov ·
Bhai Dooj 11 Nov · wedding season from mid-Nov.

| Phase | Window | Ships | Gate |
|---|---|---|---|
| 0 | 13–15 Oct | Decisions, data cleanup, accounts, repo setup | CP0 |
| 1 | 15–21 Oct | Karva Chauth page + request-lite booking | CP1 (21 Oct) |
| 1b | 21–24 Oct | Full landing, public menu, artists, reels, domain switch | CP2 (24 Oct) |
| 1.5 | 26 Oct–3 Nov | Gift cards for Diwali / Bhai Dooj | CP3 (3 Nov) |
| 2 | 4–30 Nov | Slot engine, Today board, OTP, deposits, instant booking, reminders | CP4 (30 Nov) |
| 3 | 1–20 Dec | Campaign CMS, packages, funnel analytics, rebook nudges, polish | CP5 (20 Dec) |

---

## Phase 0 — Foundations (13–15 Oct)

| ID | Task | Acceptance |
|---|---|---|
| T0.1 | [ ] Make the GitHub repo private; add Pursharth + owner as collaborators | Repo private; Vercel deploys still work |
| T0.2 | [ ] Owner decisions meeting: Q1–Q10 (CF §24) | Answers written into CF §24 |
| T0.3 | [ ] Export service catalogue; owner marks `showOnWebsite`, `audience`, public names, exceptions to 50% | Signed-off sheet in `docs/customer-platform/data/services-public.csv` |
| T0.4 | [ ] Migration M3 (`publicPrice`) + M4 (categories) with `--dry-run` | Dry-run report reviewed; applied |
| T0.5 | [ ] Migration M2 (durations from `actualDurationMins`) | Report lists services still without duration |
| T0.6 | [ ] Add backend test runner (`node:test` + `mongodb-memory-server` replica set) | `npm test` runs in CI with one passing test |
| T0.7 | [ ] Scaffold `customer/` (Next.js App Router, TS, Tailwind 4, ESLint, `typecheck` script) | Vercel project "experts-customer" deploys a placeholder on a preview URL |
| T0.8 | [ ] Confirm Vercel plan (cron frequency), create env vars in all three projects | CF §22 vars present (placeholders OK) |
| T0.9 | [ ] Submit WhatsApp templates in Wati: request received, booking confirmed, reminder 24h, reminder 2h, cancelled, OTP (auth), gift card | All submitted; approval status tracked here |
| T0.10 | [ ] Content shoot: 1 day, women's work first (colour, keratin, facial, bridal look), 6–8 before/after pairs, 1 hero loop, artist portraits, ladies' area photos. Consent form signed per client | Assets in shared drive, consent sheet complete |
| T0.11 | [ ] Cloudflare Turnstile site + secret keys | Keys in env |
| T0.12 | [ ] Google Places API key restricted to Places (New); find `SALON_PLACE_ID` | Key + place ID in env |

---

## Phase 1 — Karva Chauth request-lite (15–21 Oct) → CP1

Backend
| ID | Task | Acceptance |
|---|---|---|
| T1.1 | [ ] Service model: public fields (CF §2.1) + migration | Existing staff flows unaffected (manual smoke test) |
| T1.2 | [ ] Artist model: `publicProfile`, `gender`, `level`, `onlineBookable` | Owner can edit via API |
| T1.3 | [ ] `Customer` model + M1 backfill | Count ≈ unique contacts in Visits (1,779 as of 13 Oct) |
| T1.4 | [ ] `Appointment` model (fields needed for request-lite + full schema stubs) | Indexes created |
| T1.5 | [ ] `SiteSettings` singleton + seed | GET returns hours/contact |
| T1.6 | [ ] Mongo-backed rate limiter for `/api/public/*` (`RateLimitHit`) | Tests: limit enforced across two app instances |
| T1.7 | [ ] Public routes: `GET /site`, `/services`, `/services/:slug`, `/artists`, `/packages` (static KC packages), `POST /requests` (request-lite, Turnstile) | Returns public fields only (test asserts no `price`, `commission`, phone of staff) |
| T1.8 | [ ] Telegram alert on new request (reuse `utils/telegram.js`) | Owner receives within 10s |
| T1.9 | [ ] CORS: add customer + app domains | Preflight passes from preview and prod |

Staff app
| ID | Task | Acceptance |
|---|---|---|
| T1.10 | [ ] "Requests" list page (`bookings.view`): requested → confirm with time / decline, note field | Receptionist can process a request in < 30s |
| T1.11 | [ ] Add `bookings.view`, `bookings.manage` permissions + defaults | Permission editor shows them |

Customer site
| ID | Task | Acceptance |
|---|---|---|
| T1.12 | [ ] Design tokens, fonts, base components (Button, Chip, PriceTag, ServiceCard) per DS §3, §5 | Storybook-free visual check page at `/_dev/ui` (excluded from prod) |
| T1.13 | [ ] `/offers/karva-chauth` landing: hero, 2–3 packages, before/after (or photos), FAQ, request form | Lighthouse mobile ≥ 90 perf; LCP ≤ 2.5s throttled |
| T1.14 | [ ] Request-lite booking sheet (services → date + window → details) with honest "request" wording | Creates Appointment; Telegram fires; thank-you screen |
| T1.15 | [ ] UTM capture (first touch) + attach to request | UTM visible on the request in staff app |
| T1.16 | [ ] WhatsApp button + sticky mobile bar | Opens WhatsApp with prefilled text |

---

## Phase 1b — Full site launch (21–24 Oct) → CP2

| ID | Task | Acceptance |
|---|---|---|
| T1.17 | [ ] Home page sections 1–13 (DS §6.1) with motion system (DS §4) | Reduced-motion mode verified |
| T1.18 | [ ] `/services` and `/services/[slug]` with variant selector | All `showOnWebsite` services reachable |
| T1.19 | [ ] `/artists/[slug]` | "Book with" pre-fills artist |
| T1.20 | [ ] Reels: manual upload (until Instagram API confirmed) via `/api/website/reels`; `ReelTile` + lightbox | One video plays at a time on mobile |
| T1.21 | [ ] Google reviews cache (daily cron) + `RatingBadge` | Shows live rating with attribution |
| T1.22 | [ ] SEO: metadata, JSON-LD (HairSalon, Service), sitemap, robots | Rich results test passes |
| T1.23 | [ ] Domain switch: staff app → `app.thexpertshair.com`; customer → apex + www; redirects for `/signin`, `/dashboard/*`, `/visit-entry` etc. to app subdomain | Staff can log in on new domain; old staff URLs redirect; Telegram gate still works |
| T1.24 | [ ] Revalidate endpoint in `customer/` + backend calls on service/artist edits | Edit in staff app reflects on site ≤ 60s |
| T1.25 | [ ] Legal pages: privacy (consent, data use), terms, cancellation policy | Linked in footer and booking form |

---

## Phase 1.5 — Gift cards (26 Oct–3 Nov) → CP3

| ID | Task | Acceptance |
|---|---|---|
| T1.5.1 | [ ] `GiftCard` model, code generator (unambiguous alphabet), hashing | Unit tests |
| T1.5.2 | [ ] Razorpay order `kind=giftcard` + webhook branch | Card created only from webhook; replay-safe |
| T1.5.3 | [ ] `/gift-cards` page and purchase flow (OTP optional in 1.5: Turnstile + phone) | End-to-end test with Razorpay test mode |
| T1.5.4 | [ ] WhatsApp delivery to purchaser (+ recipient optional) | Template approved and sending |
| T1.5.5 | [ ] Visit: `giftCardAmount` bucket + redemption UI in Visit Entry + atomic balance update | Invariant test: buckets sum to `finalTotal` |
| T1.5.6 | [ ] Payments/analytics: show gift card sales separately; cash collection excludes gift card amounts | Reports reconcile with Razorpay |

---

## Phase 2 — Real booking (4–30 Nov) → CP4

Engine and data
| ID | Task | Acceptance |
|---|---|---|
| T2.1 | [ ] Artist `skills`, `schedule`, `onlineShare`; `TimeOff`; `Resource` models + staff UI | Owner sets full week for all artists |
| T2.2 | [ ] `SlotLock` model with unique + TTL indexes | Index test |
| T2.3 | [ ] Time utilities (IST grid, opening hours, holidays) with tests around UTC midnight | E20 passes |
| T2.4 | [ ] Availability engine (CF §4) as pure module + tests | E9, E13, E14 pass; 1,000 random scenarios never double-assign |
| T2.5 | [ ] `GET /availability`, `POST /quote` | Server ignores client prices |
| T2.6 | [ ] OTP (`OtpChallenge`, Wati auth template, dev channel) + `bookingToken` | Limits per CF §14 |
| T2.7 | [ ] Create-appointment transaction (CF §5.1) | E1, E11, E12, E17, E19 pass under concurrent test |
| T2.8 | [ ] Deposits: Razorpay order, webhook branch, verify-payment, hold expiry handling | E3, E4, E5 pass |
| T2.9 | [ ] Move public rate limiting fully to Mongo store; exempt verify-payment | Load test: 50 parallel availability calls OK |
| T2.10 | [ ] Request mode on engine (holds until SLA) + Telegram approve/decline buttons | Approve from Telegram confirms booking |
| T2.11 | [ ] Manage link: view, .ics, cancel, reschedule (CF §9) | Cutoff rules enforced |
| T2.12 | [ ] Cron `bookings-tick` (expiry, reminders, review requests) with `JobRun` lock | Idempotent on double run |
| T2.13 | [ ] `NotificationLog` + `notify()` wrapper | E21 passes |

Staff app
| ID | Task | Acceptance |
|---|---|---|
| T2.14 | [ ] Today board (CF §7): timeline per artist, now line, legend, 30s poll | Matches mockup; renders 10 artists × 12h |
| T2.15 | [ ] Walk-in quick add (≤ 3 taps) writing firm locks | E2 passes |
| T2.16 | [ ] Check-in → Visit Entry prefilled; `/visits/v2` accepts `appointmentId`; deposit maths (CF §8) | Examples A, B, C pass as tests |
| T2.17 | [ ] Move/reassign, no-show, cancel, refund, block time | Audit log entries for each |
| T2.18 | [ ] Conflict warnings: leave/holiday over bookings (E8, E23) | Warning lists affected bookings |

Customer site
| ID | Task | Acceptance |
|---|---|---|
| T2.19 | [ ] Full booking sheet (DS §7): who → services → professional → time → details/OTP → deposit → done | Works in Instagram in-app browser on Android |
| T2.20 | [ ] Group booking (up to 4 guests) | E13 passes |
| T2.21 | [ ] `/booking/[token]` manage page | Cancel/reschedule flows tested |
| T2.22 | [ ] Switch site from request-lite to engine per artist (`onlineBookable`) | Barbers still walk-in only |

Rollout: women's artists only for the first 2 weeks (Q4), then review CP4 metrics.

---

## Phase 3 — Growth tools (1–20 Dec) → CP5

| ID | Task | Acceptance |
|---|---|---|
| T3.1 | [ ] Campaign CMS: banners, popups (trigger, frequency), schedule | Owner creates a campaign without developer help |
| T3.2 | [ ] Promo codes with caps (server-validated) | E17 passes |
| T3.3 | [ ] Packages with total/day caps, bookable via engine | E18 passes |
| T3.4 | [ ] Funnel events + Funnel report by `utm_campaign` with revenue | Report reconciles with Visits revenue |
| T3.5 | [ ] Rebook nudges (opt-in only) per service interval | Sends only to opted-in customers |
| T3.6 | [ ] Instagram API sync (if Q7 = yes) + token refresh + owner tagging "Book this look" | Token refresh alert tested |
| T3.7 | [ ] Meta Conversions API `Schedule` event on confirmed bookings (consent-gated) | Event visible in Meta Events Manager test tool |
| T3.8 | [ ] Weekday "Happy Hour" off-peak offer as a campaign with time windows | Applies only inside the window |
| T3.9 | [ ] Membership / prepaid wallet design doc (owner decision first) | Doc approved before any build |
| T3.10 | [ ] Accessibility audit (WCAG 2.1 AA) and performance re-audit | DS §9 and §10 budgets met |

---

## Backlog (not scheduled)

- Colour processing time (artist free while colour develops).
- Re-host reels on Cloudinary/Vercel Blob with 720p transcodes.
- SMS OTP fallback after MSG91 DLT registration.
- Customer accounts with saved preferences (currently phone + OTP only).
- Hindi/Punjabi language toggle.
- Waitlist for fully booked festive days.

---

## Log

| Date | Task | Note |
|---|---|---|
| 13 Oct 2026 | — | Plan created |
