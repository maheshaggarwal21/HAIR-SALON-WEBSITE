# CONTROL_FLOW_AND_DATA_LOGIC.md

How the customer website, booking engine, staff app and payments work together.
Every backend change for the customer platform must match this document. If you need
to deviate, update this file and the Decisions table (§24) in the same PR.

Status: v1, 13 Oct 2026. Based on repo commit `d2adb97`.

---

## 1. Architecture

```mermaid
flowchart TB
  subgraph Public["Public (no login)"]
    C["customer/ — Next.js<br/>thexpertshair.com"]
  end
  subgraph Staff["Staff (session cookie)"]
    S["frontend/ — React staff app<br/>app.thexpertshair.com"]
  end
  subgraph API["backend/ — Express on Vercel<br/>api.thexpertshair.com"]
    P["/api/public/*<br/>read catalogue, quote,<br/>availability, OTP, book"]
    B["/api/bookings/*<br/>Today board, check-in"]
    W["/api/website/*<br/>CMS, campaigns, schedules"]
    E["existing /api/visits, /analytics,<br/>/services, /artists, ..."]
    BE["Booking engine<br/>(availability + slot locks)"]
    J["/api/cron/* jobs"]
    WH["/api/razorpay/webhook"]
  end
  DB[("MongoDB Atlas<br/>single source of truth")]
  RZ["Razorpay"]
  WA["WhatsApp (Wati)"]
  TG["Telegram bot"]
  IG["Instagram API"]
  GP["Google Places API"]

  C --> P
  S --> B & W & E
  P --> BE
  B --> BE
  BE --> DB
  P & B & W & E --> DB
  RZ --> WH --> DB
  J --> WA & TG & IG & GP
  P -. "revalidate tags" .-> C
  W -. "on-demand revalidate" .-> C
```

### 1.1 Domains and request paths

| Caller | Calls | Auth | Cookies |
|---|---|---|---|
| Customer site (server components) | `https://api.thexpertshair.com/api/public/*` | none | none |
| Customer site (browser, booking sheet) | same, via Next.js rewrite `/api/public/*` → API (same-origin) | short-lived `bookingToken` in body after OTP | none |
| Staff app | `/api/*` via Vercel rewrite to API (existing pattern, avoids Safari ITP) | express-session | `connect.sid`, `salon_device` |
| Razorpay | `/api/razorpay/webhook` | HMAC signature | none |
| Vercel Cron | `/api/cron/*` | `Authorization: Bearer $CRON_SECRET` | none |

CORS: add `https://thexpertshair.com`, `https://www.thexpertshair.com`,
`https://app.thexpertshair.com` to `ALLOWED_ORIGINS`. Public routes do not need
`credentials`.

---

## 2. Data model

Notation: `?` = optional. All dates are UTC `Date`. Money is whole rupees (`Number`).

### 2.1 Changes to existing models

**Service** (`backend/models/Service.js`) — add public layer. Internal fields unchanged.

| Field | Type | Notes |
|---|---|---|
| `publicPrice` | Number | What the customer pays. Migration M3 sets `round(price × 0.5)`; owner reviews exceptions |
| `showOnWebsite` | Boolean, default false | Curated menu. Typos and "Any item" never get this |
| `slug` | String, unique sparse | URL key |
| `publicName` | String? | Clean name, e.g. "Smoothening" instead of "Smoothening (Women) Medium" |
| `audience` | `her` \| `him` \| `unisex` | Drives For her / For him tabs |
| `displayCategory` | String | Normalised: Hair, Colour, Treatments, Skin, Waxing, Threading, Hands & feet, Makeup, Grooming |
| `variantGroup` | String? | Services sharing a group show as ONE public card with a selector |
| `variantLabel` | String? | "Short", "Medium", "Long" |
| `addOnIds` | [ObjectId] | Other services offered as add-ons (they are real services, so they bill normally) |
| `shortDescription`, `description` | String? | |
| `images` | [String] | URLs |
| `durationMinutes` | Number | Exists. REQUIRED when `bookingMode = instant` |
| `bufferMinutes` | Number, default 0 | Cleanup time after the service |
| `bookingMode` | `instant` \| `request` \| `walkin_only` \| `hidden` | Default `hidden` |
| `requiresConsultation` | Boolean | Forces `request` |
| `requiresPatchTest` | Boolean | Colour services. Shown as badge; checked against `Customer.patchTestDoneAt` |
| `depositAmount` | Number, default 0 | Per-service deposit rule |
| `resourceIds` | [ObjectId] | Facial bed, pedicure station, makeup chair, etc. |
| `featured`, `sortOrder` | Boolean, Number | Landing page ordering |
| `seo` | `{title?, description?}` | |

Why variants are separate existing services and not price options: the catalogue
already has "Smoothening (Women) Short/Medium/Long" as separate services. Grouping them
keeps every booked item a real `serviceId`, so Visits, analytics and artist attribution
work unchanged.

**Artist** (`backend/models/Artist.js`)

| Field | Type | Notes |
|---|---|---|
| `skills` | [ObjectId → Service] | Services this artist can perform. Empty = cannot be booked online |
| `gender` | `female` \| `male` \| `other`? | Only used for the optional "female artist" filter |
| `level` | `senior` \| `stylist` \| `junior`? | Display only in v1 |
| `onlineBookable` | Boolean, default false | Master switch |
| `onlineShare` | Number 0–100, default 100 | Max % of the artist's working minutes per day sellable online. Barbers start at 0–40 |
| `schedule.weekly` | `{mon..sun: [{start:"HH:mm", end:"HH:mm"}]}` | IST wall-clock |
| `schedule.breaks` | `[{day, start, end}]` | |
| `publicProfile` | `{slug, displayName, bio, specialties[], photo, portfolio[], instagram, sortOrder, visible}` | |

**Visit** (`backend/models/Visit.js`)

| Field | Type | Notes |
|---|---|---|
| `customerId` | ObjectId? | Set on every new visit (desk lookup by phone) |
| `appointmentId` | ObjectId? | Set when created from a booking or walk-in record |
| `source` | `{channel: web\|desk\|phone\|whatsapp\|walkin, utm?{source,medium,campaign,content}, campaignId?, promoCode?}` | Attribution |
| `services[].listPrice` | Number? | Snapshot of `Service.price` for online-origin visits |
| `depositAmount` | Number, default 0 | Already-received online money |
| `depositPaymentId` | String?, unique sparse | Razorpay id of the deposit |
| `discountReason` | String? | `campaign:<slug>`, `promo:<code>`, `desk` |
| `giftCardAmount` | Number, default 0 | Phase 1.5. Joins the payment invariant |
| `giftCardRedemptions` | `[{giftCardId, amount}]` | Phase 1.5 |

**PaymentEvent** (`backend/models/PaymentEvent.js`)

| Field | Type | Notes |
|---|---|---|
| `purpose` | `visit` \| `deposit` \| `giftcard` | From Razorpay order `notes.kind` |
| `appointmentId` | ObjectId? | Deposits |
| `giftCardId` | ObjectId? | Gift card sales |
| `reconcileStatus` | add `matched_appointment`, `matched_giftcard` | |

**User permissions** (`backend/constants/permissions.js`) — see §19.

### 2.2 New models

**Customer**

| Field | Type | Notes |
|---|---|---|
| `phone` | String, unique | 10-digit Indian mobile |
| `name` | String | Latest known |
| `gender` | `female`\|`male`\|`other`\|`prefer_not`? | Of this person, not the booker |
| `email` | String? | |
| `householdId` | ObjectId? | Links family members booked together |
| `preferredArtistId` | ObjectId? | |
| `patchTestDoneAt` | Date? | The only health-adjacent field allowed |
| `marketing` | `{whatsappOptIn: Boolean, at?, source?}` | Unticked by default |
| `policyAcceptedAt`, `policyVersion` | Date?, String? | |
| `stats` | `{visits, lastVisitAt, firstVisitAt, noShows, lateCancels}` | Maintained by hooks + nightly job |
| `firstTouch` | `{utm?, at}` | |
| `createdFrom` | `backfill` \| `web` \| `desk` | |

**Appointment** — a booking OR a walk-in. Walk-ins are appointments with
`source.channel = walkin` created directly in `checked_in`. This keeps the Today board
and slot locks on one model.

```js
{
  ref: "EXP-7K3Q9",                 // human code, unique
  mode: "instant" | "request",
  status: "pending_payment" | "requested" | "confirmed" | "checked_in" |
          "completed" | "cancelled" | "declined" | "expired" | "no_show",
  customerId, contact, name,        // the booker
  guests: [{
    guestKey: "g1",
    name, gender, customerId?,      // guest's own customer record if phone given
    items: [{
      serviceId, name, publicPrice, listPrice,
      durationMin, bufferMin,
      artistId, artistName,
      startAt, endAt,               // service window, excluding buffer
      resourceIds: []
    }]
  }],
  startAt, endAt,                   // whole appointment, including buffers
  pricing: { subtotal, discount, total, promoCode?, packageId?, campaignId? },
  deposit: { required: Boolean, amount, status: "none"|"pending"|"paid"|
             "refunded"|"forfeited"|"applied", razorpayOrderId?, razorpayPaymentId?, paidAt? },
  holdExpiresAt?, requestExpiresAt?,
  source: { channel, utm?, campaignId?, promoCode? },
  policyVersion, policyAcceptedAt,
  notes?,                            // customer note, max 300 chars
  manageTokenHash,                   // sha256 of the token in the manage link
  rescheduleCount: 0,
  checkedInAt?, visitId?,
  cancelledAt?, cancelledBy?: "customer"|"salon"|"system", cancelReason?,
  createdBy?: userId,                // staff-created bookings
  statusHistory: [{ from, to, at, by, reason }]
}
```

Indexes: `{ref:1}` unique · `{status:1, startAt:1}` · `{customerId:1, startAt:-1}` ·
`{contact:1, status:1}` · `{"guests.items.artistId":1, startAt:1}` · `{holdExpiresAt:1}` · `{requestExpiresAt:1}`.

**SlotLock** — the double-booking guard.

```js
{
  artistId,            // or resourceId for resource locks (see kind)
  kind: "artist" | "resource",
  resourceUnit?: 0,    // for resources with capacity > 1
  blockStart,          // UTC instant aligned to 15-min grid in IST
  appointmentId,
  state: "hold" | "firm",
  expiresAt?           // set only for holds
}
```
Indexes: unique `{kind:1, artistId:1, resourceUnit:1, blockStart:1}` ·
TTL `{expiresAt:1}, expireAfterSeconds: 0` (firm locks have no `expiresAt` and never expire).

**OtpChallenge** `{phoneHash, codeHash, purpose: "booking"|"manage"|"giftcard", attempts, expiresAt (5 min, TTL), consumedAt?, channel: "whatsapp"|"sms"|"dev"}`

**TimeOff** `{artistId, startAt, endAt, reason?, createdBy}`

**Resource** `{name, capacity, serviceIds[], active}`

**SiteSettings** (singleton)

```js
{
  timezone: "Asia/Kolkata",
  openingHours: { mon: [{open:"09:00", close:"20:00"}], ... },
  holidays: ["2026-11-08"], specialHours: [{date, open, close}],
  slotMinutes: 15, minLeadMinutes: 120, horizonDays: 30,
  holdMinutes: 10, requestSlaMinutes: 120,
  cancellationCutoffHours: 24, maxActiveBookingsPerPhone: 3, maxGuests: 4,
  maxOnlineReschedules: 2, noShowGraceMinutes: 15,
  deposit: { peakDates: ["2026-10-28","2026-10-29"], peakDayAmount: 200,
             repeatNoShowAmount: 200, repeatNoShowThreshold: 2 },
  policyVersion: "2026-10-v1",
  contact: { phone, whatsapp, mapUrl, address, placeId },
  publicPriceRatio: 0.5
}
```

**Campaign** `{slug, name, status (derived from dates), startsAt, endsAt, audience, placements: ["home_strip","popup","offers_page"], popup?: {trigger: "delay"|"scroll"|"exit", value, frequency: "session"|"day"}, content: {eyebrow, headline, body, image, ctaLabel, ctaHref}, promo?: {code, type: "percent"|"flat", value, serviceIds?, minSpend?, maxUses?, uses, perCustomerLimit?}, utmCampaign}`

**Package** `{slug, name, description, image, items: [serviceId], packagePrice, validFrom, validTo, bookableDates?: [date], capTotal?, capPerDay?, sold, audience, campaignId?}`

**GiftCard** (Phase 1.5) `{codeHash, codeLast4, initialValue, balance, status: "active"|"redeemed"|"expired"|"void", purchaser: {name, phone}, recipient: {name, phone?, message?}, expiresAt (12 months), paymentEventId, redemptions: [{visitId, amount, at, by}]}`. Closed-loop: usable only at this salon.

**Reel** `{igMediaId, mediaType, mediaUrl, thumbnailUrl, permalink, caption, postedAt, visible, serviceId?, sortOrder, urlRefreshedAt}`

**ReviewCache** `{rating, count, reviews: [{author, rating, text, relativeTime, profilePhoto}], fetchedAt, attribution}`

**NotificationLog** `{key (unique), appointmentId?, type, channel, to, status: "sent"|"failed"|"skipped", providerId?, error?, sentAt}`. `key = "<appointmentId>:<type>"` makes every send idempotent.

**PublicEvent** `{sessionId, type, props, utm, path, at}` TTL 180 days, no PII.

**JobRun** `{name (unique), lockedUntil, lastRunAt, lastResult}` — cron overlap guard.

**RateLimitHit** `{key, windowStart, count}` TTL — shared limiter for public routes.

---

## 3. Appointment state machine

```mermaid
stateDiagram-v2
  [*] --> pending_payment: deposit required
  [*] --> confirmed: instant, no deposit
  [*] --> requested: request, no deposit
  [*] --> checked_in: walk-in at desk
  pending_payment --> confirmed: paid (instant)
  pending_payment --> requested: paid (request)
  pending_payment --> expired: hold timed out, unpaid
  requested --> confirmed: staff approves
  requested --> declined: staff declines (deposit refunded)
  requested --> expired: SLA passed (deposit refunded)
  confirmed --> checked_in: customer arrives
  confirmed --> cancelled: customer or salon cancels
  confirmed --> no_show: grace passed, staff marks
  checked_in --> completed: Visit created and paid
  checked_in --> cancelled: left before service
  completed --> [*]
```

| From → To | Who | Side effects |
|---|---|---|
| (new) → pending_payment | customer | hold locks (expires `holdMinutes`), Razorpay order |
| pending_payment → confirmed / requested | webhook or verify-payment | locks: instant → firm; request → hold until `requestExpiresAt` |
| (new) → confirmed | customer, no deposit, instant | firm locks |
| (new) → requested | customer, no deposit, request | hold locks until `requestExpiresAt` |
| requested → confirmed | staff (`bookings.manage`) | locks → firm, WhatsApp "confirmed" |
| requested → declined / expired | staff / cron | delete locks, refund deposit, WhatsApp |
| confirmed → cancelled | customer before cutoff | delete locks, deposit refunded |
| confirmed → cancelled | customer after cutoff | delete locks, deposit forfeited (owner may waive) |
| confirmed → cancelled | salon | delete locks, deposit refunded, WhatsApp apology + rebook link |
| confirmed → no_show | staff after `noShowGraceMinutes` | delete future locks, deposit forfeited, `stats.noShows++` |
| confirmed → checked_in | staff | `checkedInAt`, opens visit entry prefilled |
| checked_in → completed | visit creation | `visitId`, deposit `applied`, `stats.visits++` |

Locks are deleted (not kept) on cancel/decline/expire/no-show so the time becomes
sellable immediately. History lives in `statusHistory`.

---

## 4. Availability engine

Pure function, unit-tested, no I/O inside the core:

```
availability(date, guests[], artistPref?, now) → slots[]
```

### 4.1 Inputs it loads first
1. `SiteSettings` (hours, holidays, special hours, lead time, horizon).
2. Services for all requested items (duration, buffer, skills needed, resources, bookingMode).
3. Candidate artists: `active && onlineBookable && skills ⊇ item.serviceId` (per item).
4. For each candidate artist on `date`: weekly schedule ∩ opening hours − breaks − `TimeOff`.
5. Existing `SlotLock`s for those artists/resources on `date` where `state=firm` OR `expiresAt > now`.
6. Online minutes already sold per artist that day (for `onlineShare`).

### 4.2 Algorithm (one guest)
```
G = 15 min grid
items sorted by service.sortOrder (cut before colour, threading before makeup, etc.)
for t in grid(dayOpen .. dayClose) where t >= now + minLeadMinutes:
    chain = []
    cursor = t
    ok = true
    for item in items:
        need = ceil15(item.durationMin + item.bufferMin)
        artists = eligible(item) ordered by:
                  artistPref match > artist already in chain > fewest booked minutes today > name
        pick first artist a where free(a, cursor, need) and resourcesFree(item, cursor, need)
                                  and onlineShareOK(a, need)
        if none: ok = false; break
        chain.push({item, a, start: cursor, end: cursor + item.durationMin})
        cursor += need
    if ok: emit slot {startAt: t, endAt: cursor, chain}
```
- `free(a, s, n)` = every 15-min block in `[s, s+n)` is inside a's working intervals and has no lock.
- Multiple guests (group booking): run the chain for each guest at the same `t`, with
  locks already claimed by earlier guests in this candidate treated as taken. A slot is
  valid only if every guest gets a chain.
- `artistPref = specific`: items that artist can do MUST use them; other items may use others.
- Slots are returned grouped (morning < 12:00 ≤ afternoon < 16:00 ≤ evening) with
  `remaining` = count of distinct chains at that time (used for honest "2 left").
- `walkin_only` and `hidden` services are rejected. Any `request` item → appointment mode `request`.
- `requiresPatchTest` and customer has no `patchTestDoneAt` within 6 months → earliest
  slot is now + 48h and the confirmation tells them to come in for a patch test.

### 4.3 Performance
5–10 artists × ~45 grid points × ≤ 4 items is tiny; compute on request. Cache the
public response for 30 seconds per `(date, items, artistPref)` key.

---

## 5. Online booking flow (instant)

```mermaid
sequenceDiagram
  participant U as Customer browser
  participant N as customer/ (Next.js)
  participant A as API /api/public
  participant D as MongoDB
  participant R as Razorpay
  participant W as WhatsApp (Wati)
  participant T as Telegram

  U->>A: GET /availability?date&items&artist
  A->>D: settings, artists, locks
  A-->>U: slots
  U->>A: POST /quote {items, promo}
  A-->>U: lines, total, deposit, mode
  U->>A: POST /otp/send {phone} (+ Turnstile)
  A->>W: auth template with code
  U->>A: POST /otp/verify {phone, code}
  A-->>U: bookingToken (30 min) + returning-customer prefill
  U->>A: POST /appointments {bookingToken, items, startAt, artistPref, consent, utm, promo}
  A->>D: TXN: re-run engine for this start, insert SlotLocks (hold), create Appointment
  alt deposit required
    A->>R: create order (notes.kind=deposit, appointmentId)
    A-->>U: {status: pending_payment, holdExpiresAt, order}
    U->>R: Checkout
    R->>A: webhook payment.captured
    A->>D: TXN: locks hold→firm, status confirmed, deposit paid, PaymentEvent matched
    U->>A: POST /appointments/:id/verify-payment (idempotent, same effect)
  else no deposit
    A->>D: locks created firm, status confirmed
    A-->>U: {status: confirmed}
  end
  A->>W: confirmation + manage link
  A->>T: owner alert
  A->>W: artist alert
```

### 5.1 The create transaction (exact order)
1. Verify `bookingToken` (HMAC, not expired, phone matches).
2. Load settings; enforce `maxActiveBookingsPerPhone` and no overlap with this phone's
   other active appointments.
3. Re-run the engine for the requested `startAt` only. If no chain → `409 SLOT_TAKEN`
   with the 3 nearest alternatives.
4. Recompute the quote server-side (ignore any price from the browser). Validate promo/package caps.
5. `session.withTransaction`:
   a. delete expired holds overlapping the target blocks (TTL lag protection);
   b. `insertMany` SlotLocks for every block of every chain item (artist + resource);
      duplicate-key → abort → `409 SLOT_TAKEN`;
   c. create Appointment;
   d. increment package `sold` / promo `uses` with conditional update (cap check); fail → abort.
6. After commit: create Razorpay order if deposit (store `razorpayOrderId`), upsert Customer,
   write notifications (Telegram/WhatsApp) BEFORE responding (serverless rule).

### 5.2 Deposit rules
`deposit = max(service.depositAmount over items, peakDayAmount if date ∈ peakDates,
repeatNoShowAmount if customer.stats.noShows ≥ threshold)`, capped at `pricing.total`.
Request-mode bookings also pay the deposit upfront; it is refunded in full if the
salon declines or the request expires.

### 5.3 Payment confirmation (webhook-first)
On `payment.captured` with `notes.kind = deposit`:
1. Upsert PaymentEvent (`purpose: deposit`, `appointmentId`).
2. TXN: if appointment is `pending_payment` and its hold locks still exist → set locks
   firm (instant) or keep as hold with `expiresAt = requestExpiresAt` (request); set
   status; `deposit.status = paid`.
3. If the hold already expired: try to re-acquire the same locks. Success → continue as
   above. Failure → `status = cancelled`, `cancelledBy = system`,
   `cancelReason = "paid_after_hold_expired"`, Telegram alert to owner, refund queued
   (staff confirms refund in the dashboard). Never silently keep the money.
4. Idempotent: replaying the webhook or calling verify-payment again changes nothing.

---

## 6. Request booking flow

Same as §5 but status becomes `requested` and locks stay `hold` with
`expiresAt = requestExpiresAt = now + requestSlaMinutes` (counted in opening hours; if
created after closing, SLA starts at next opening). Staff sees it in "Needs approval"
on the Today board and on Telegram with Approve/Decline buttons (reuse the existing
Telegram callback pattern). Approve → firm locks, WhatsApp "confirmed". Decline/expire →
delete locks, refund deposit, WhatsApp with 3 alternative times.

### 6.1 Phase 1 "request-lite" (before the slot engine exists)

Until Phase 2 ships, the website collects requests without checking live availability:
- Customer picks services, a preferred date and a window (morning / afternoon / evening),
  an optional artist preference, name and phone. Turnstile + Mongo rate limit, no OTP.
- Creates `Appointment {mode: "request", status: "requested", requestedWindow: {date, window}}`
  with NO slot locks and no deposit.
- Telegram alert to owner + WhatsApp (or manual call) to the customer. Staff confirms by
  phone/WhatsApp and records the final time in the staff app ("Confirm with time"), which
  sets `startAt/endAt` and status `confirmed`. No locks until Phase 2.
- The website must say "request" everywhere in this mode, never "booked" or "confirmed".

---

## 7. Front-desk flows (Today board)

| Action | API | Effect |
|---|---|---|
| Walk-in | `POST /api/bookings/walkin {artistId(s), serviceIds, customer phone/name, gender}` | Appointment `channel=walkin`, `status=checked_in`, firm locks from now (rounded down to 15) for the chain. Fails with clear message if the artist is locked; staff can override with `force=true` (audited) |
| Phone booking | `POST /api/bookings` | Same engine as web, `channel=phone`, `createdBy`, no OTP, deposit optional (staff choice, sends payment link) |
| Check in | `POST /api/bookings/:id/check-in` | `checked_in`; staff app opens Visit Entry prefilled from the appointment |
| Move / reassign | `PATCH /api/bookings/:id {startAt?, artistId per item?}` | TXN: acquire new locks, release old; WhatsApp to customer if time changed |
| Add service at desk | done in Visit Entry | Extra services bill normally; locks extended if artist free, otherwise warning |
| No-show | `POST /api/bookings/:id/no-show` | Allowed after `startAt + noShowGraceMinutes` |
| Cancel | `POST /api/bookings/:id/cancel {reason, refund}` | Salon cancel, refund default true |
| Refund deposit | `POST /api/bookings/:id/refund` | Razorpay refund API; audit log |
| Block time | `POST /api/bookings/block {artistId, startAt, endAt, reason}` | Firm locks with `appointmentId=null`, `kind=artist` (e.g. training) |

**Board data:** `GET /api/bookings/board?date=YYYY-MM-DD` returns artists (with working
intervals and breaks), appointments (all statuses except expired/declined/cancelled),
and request-holds. The board polls every 30s (no websockets on Vercel).

---

## 8. Check-in → Visit conversion and payment maths

The existing payment-first Visit flow stays. Conversion feeds it.

1. Staff taps Check in → Visit Entry opens with: booker name/phone, guest gender
   (`her` → `female`, `him` → `male`), the appointment's `serviceId`s, and
   `appointmentId`.
2. `POST /api/visits/v2` gains optional `appointmentId`. When present, the server:
   - uses the appointment's snapshot `publicPrice` per item as `services[].price` and
     stores `services[].listPrice`; extra desk-added services use their `publicPrice`
     if `SiteSettings.publicPriceRatio` is in use, otherwise list price with desk discount;
   - applies the appointment's promo/package discount as an absolute amount
     (`discountReason` set), never a browser-sent figure;
   - sets `depositAmount` and `depositPaymentId` from the appointment;
   - computes `remainder = finalTotal − depositAmount − giftCardAmount`;
   - payment buckets: compute remainder buckets with the existing
     `derivePaymentAmounts` (cash/card/online/partial), then `onlineAmount += depositAmount`;
   - if `remainder = 0`, no payment step is required;
   - pre-fills per-service artist and start/end times for the assignment step;
   - in the same write: appointment → `completed`, `visitId`, `deposit.status = applied`.
3. Invariant check before save: `cashAmount + cardAmount + onlineAmount + giftCardAmount
   === finalTotal`, else 500 and nothing is written.

**Example A** — booked Smoothening Medium (public ₹4,500) + Eyebrows (₹50), deposit ₹500
paid online (`pay_A`). At desk adds Head massage (₹350). Pays rest in cash.
`finalTotal = 4,900` · `depositAmount = 500, depositPaymentId = pay_A` ·
`cashAmount = 4,400` · `onlineAmount = 500` · `paymentMethod = partial`. Sum = 4,900 ✓.

**Example B** — same, rest paid by UPI (`pay_B`).
`onlineAmount = 4,900`, `razorpayPaymentId = pay_B`, `depositPaymentId = pay_A`. ✓

**Example C** — deposit ₹500 covers a ₹450 total (rare). Charge ₹450 from deposit;
₹50 refunded via Razorpay refund, recorded in PaymentEvent. Never leave unexplained money.

Analytics impact: revenue still = `finalTotal`. Online-origin visits carry real prices
with zero blanket discount; desk visits keep list price + 50% until the owner decides
Q1 (§24). "Discounts given" reports should filter by `discountReason` once Q1 is settled.

Forfeited deposits (late cancel, no-show) are reported as a separate line
"Forfeited deposits", never as service revenue.

---

## 9. Customer self-service (manage link)

Manage URL: `/booking/<token>` where `token` = 32 random bytes (base64url), only the
sha256 is stored. Allowed actions:
- view, add to calendar (.ics), directions;
- cancel (before cutoff → refund; after → forfeited, shown clearly before confirming);
- reschedule up to `maxOnlineReschedules`, only before cutoff; deposit carries over;
  executed as one TXN (acquire new locks, release old).
High-risk actions (cancel, reschedule) require a fresh WhatsApp OTP if the link is older than 24h.

---

## 10. Gift cards (Phase 1.5)

Purchase: `POST /api/public/gift-cards/order {amount, purchaser, recipient, otp-verified token}`
→ Razorpay order `notes.kind=giftcard` → webhook creates `GiftCard` (code shown once,
WhatsApp to purchaser; to recipient if phone given and purchaser opts in).
Amounts: ₹1,000 / ₹2,000 / ₹3,000 / ₹5,000 / custom ₹500–₹20,000.

Redemption at desk: staff enters code → `GET /api/giftcards/lookup?code` (permission
`giftcards.manage` or `visit.create`) → apply up to balance. Balance update is atomic:
`updateOne({_id, balance: {$gte: amt}, status: "active"}, {$inc: {balance: -amt}, $push: {redemptions}})`.
Sales of gift cards are reported as "Gift card sales" (liability), not revenue. Revenue
is recognised when redeemed inside a Visit.

---

## 11. Notifications

| Event | Customer (WhatsApp) | Owner (Telegram) | Artist (WhatsApp) |
|---|---|---|---|
| OTP | auth template | — | — |
| Booking confirmed | confirmation + manage link + map | new booking summary | new booking on your day |
| Request received | "request sent, we'll confirm within 2 working hours" | approve/decline buttons | — |
| Request approved / declined | confirmed / declined + 3 alternatives | — | approved → new booking |
| 24h reminder | reminder + manage link | — | — |
| 2h reminder | reminder + directions | — | day sheet at opening (one message) |
| Cancelled (any side) | cancellation + refund status | alert | slot freed |
| Paid after hold expired | apology, refund in progress | urgent alert | — |
| Visit completed + 2h | review request (Google link) | — | — |
| Rebook nudge | per service rule (root touch-up 30d, threading 21d, facial 30d, beard 14d) only if `whatsappOptIn` | — | — |

All WhatsApp templates need Meta approval through Wati. Submit them on day 1 (T0.9) —
approval can take 1–2 days. Every send goes through `notify(key, ...)`, which checks
`NotificationLog` first (idempotent) and records the result. Failures never block a booking.

---

## 12. Content, campaigns and revalidation

- Owner edits in the staff app (`/api/website/*`). Each write calls
  `revalidate(tags)` → `POST https://thexpertshair.com/api/revalidate` with
  `REVALIDATE_SECRET` and tags such as `services`, `artists`, `campaigns`, `site`, `reels`.
- Customer pages fetch with `next: { tags: [...], revalidate: 3600 }`. Availability and
  quotes are never cached in Next.
- Campaign visibility = `startsAt ≤ now < endsAt` (computed server-side, IST-aware). Popups:
  max one per session, client respects `frequency` using sessionStorage/localStorage in try/catch.
- Promo codes: validated at `/quote`, re-validated inside the create TXN with conditional
  `$inc` on `uses`. Never stack promo + package. Discount applies to public-price subtotal.
- Packages: booked like a service bundle; `capPerDay` checked per `bookableDate`.

---

## 13. Instagram and Google reviews

**Instagram:** Instagram API with Instagram Login (Business/Creator account). Daily cron
`/api/cron/instagram-sync` fetches recent media (`id, media_type, media_url,
thumbnail_url, permalink, caption, timestamp`), upserts `Reel`, refreshes `media_url`.
Long-lived token (60 days) refreshed weekly by the same job; owner alerted on Telegram
if refresh fails. Owner toggles `visible` and tags `serviceId` for "Book this look".
v2: re-host chosen reels (transcoded 720p) on Cloudinary or Vercel Blob for speed.

**Google reviews:** daily cron calls Places API (New) Place Details for the salon's
`placeId` (`rating, userRatingCount, reviews`), stores `ReviewCache`, displays with
Google attribution. Do not edit or filter reviews by rating.

---

## 14. Public API (`/api/public/*`)

| Method | Path | Purpose | Limits |
|---|---|---|---|
| GET | `/site` | settings subset, hours, contact, rating, live campaigns | cached |
| GET | `/services?for=her\|him` | public menu (grouped variants, add-ons) | cached |
| GET | `/services/:slug` | detail | cached |
| GET | `/artists`, `/artists/:slug` | public profiles | cached |
| GET | `/packages` | live packages with remaining caps | cached 60s |
| GET | `/reels`, `/reviews` | feeds | cached |
| POST | `/quote` | server price/deposit/mode for a selection | 60/IP/min |
| GET | `/availability` | slots for a date | 60/IP/min |
| POST | `/otp/send` | send code | Turnstile · 3/phone/15 min · 10/IP/hour |
| POST | `/otp/verify` | returns `bookingToken` | 5 attempts per challenge |
| POST | `/appointments` | create booking | Turnstile · 5/phone/day |
| POST | `/appointments/:id/verify-payment` | browser confirmation (idempotent) | exempt (payment-critical) |
| GET | `/booking/:token` | manage view | 30/IP/min |
| POST | `/booking/:token/cancel`, `/reschedule` | self-service | 5/token/day |
| POST | `/gift-cards/order` | Phase 1.5 | Turnstile |
| POST | `/events` | anonymous funnel events (batched) | 120/IP/min |

Responses never include other customers' data, staff phone numbers, list prices,
commission or internal notes. Errors use stable codes: `SLOT_TAKEN`, `OTP_INVALID`,
`OTP_EXPIRED`, `LIMIT_REACHED`, `PROMO_INVALID`, `PACKAGE_SOLD_OUT`, `OUTSIDE_HOURS`.

Rate limiting: the existing global `express-rate-limit` uses an in-memory store, which
is per serverless instance. Public routes use a Mongo-backed limiter (`RateLimitHit`)
keyed by IP and/or phone hash. Do not mount the public router under the existing global
limiter's assumptions (all salon devices share one IP; public users don't).

---

## 15. Staff API additions

`/api/bookings/*` (§7) · `/api/website/settings` · `/api/website/services/:id/public` ·
`/api/website/artists/:id/public` · `/api/website/artists/:id/schedule` ·
`/api/website/time-off` · `/api/website/resources` · `/api/website/campaigns` ·
`/api/website/packages` · `/api/website/reels` · `/api/website/media` (upload) ·
`/api/giftcards/*` · `/api/analytics/funnel`.

Every mutation writes `AuditLog` with before/after.

---

## 16. Cron jobs (Vercel Cron → `/api/cron/*`)

| Job | Schedule | Does |
|---|---|---|
| `bookings-tick` | every 15 min | expire unpaid holds (status `expired`), expire request SLAs (refund queue), 24h and 2h reminders, review requests 2h after completion |
| `daily-morning` | 08:15 IST | artist day sheets, owner summary on Telegram (today's bookings, requests pending, deposits) |
| `nightly` | 02:30 IST | Customer stats refresh, rebook nudges queue, Instagram sync, reviews refresh |
| `weekly` | Sun 03:00 IST | Instagram token refresh, purge old PublicEvents (TTL backup) |

Every job: verify `CRON_SECRET`, take a `JobRun` lock (`lockedUntil = now + 10 min`),
be idempotent, finish all writes before responding. Note: Vercel Hobby limits cron to
daily; the existing `*/5` health cron implies Pro. Confirm the plan (T0.8).

---

## 17. Analytics and attribution

- On first landing, the customer site stores `utm_*` and `fbclid` (first touch, 30 days)
  and an anonymous `sessionId` (localStorage, try/catch).
- Funnel events: `view_home`, `view_service`, `open_booking`, `select_service`,
  `select_slot`, `otp_sent`, `otp_verified`, `booking_created`, `booking_confirmed`.
- Attribution chain: `PublicEvent.utm` → `Appointment.source` → `Visit.source` → revenue.
- Staff app "Website" → Funnel report: counts per step and revenue per `utm_campaign`
  (completed visits only). This is the ROI proof for paid ads.
- Phase 3: Meta Conversions API server-side `Schedule` event on `booking_confirmed`
  (hashed phone, only with consent).

---

## 18. Security

- Public endpoints validate with `express-validator`; reject unknown fields.
- `bookingToken`: HMAC-SHA256 with `PUBLIC_TOKEN_SECRET`, payload `{phoneHash, exp}`, 30 min.
- OTP: 6 digits from `crypto.randomInt`, stored as salted sha256, 5-min expiry, 5 attempts.
- Turnstile verified server-side on OTP send, appointment create, gift-card order.
- Manage tokens stored hashed; links are unguessable; no enumeration by phone.
- Helmet already on. Add CSP on the customer site (allow Razorpay checkout, Turnstile,
  Google Maps embed, Instagram CDN, fonts).
- Webhook: existing HMAC check; extend matching by `notes.kind`.
- Make the GitHub repo private (T0.1). It currently exposes the full business logic.

---

## 19. Permissions (add to `PERMISSIONS`)

| Key | Label | Default roles |
|---|---|---|
| `bookings.view` | View Today board and bookings | receptionist, manager |
| `bookings.manage` | Create, move, approve, check in, cancel bookings | receptionist, manager |
| `bookings.refund` | Refund deposits | (owner only by default) |
| `schedules.manage` | Edit artist schedules and time off | manager |
| `website.manage` | Edit website content, public menu, artist profiles | (owner only by default) |
| `campaigns.manage` | Campaigns, popups, promo codes, packages | (owner only by default) |
| `giftcards.manage` | Look up, redeem, void gift cards | receptionist (lookup + redeem), manager |

---

## 20. Data migrations (all with `--dry-run`, all logged)

| ID | What | Rule |
|---|---|---|
| M1 | Backfill `Customer` from `Visit` | group by `contact`; latest name; first/last visit; visit count; `createdFrom: backfill` |
| M2 | Seed `Service.durationMinutes` | median of `actualDurationMins` where ≥ 5 samples, rounded up to 5 min; else leave null and list for owner |
| M3 | Seed `Service.publicPrice` | `round(price × 0.5)`; export list for owner review |
| M4 | Normalise categories | trim + title-case existing `category`; map to `displayCategory`; flag outliers (e.g. "Side Locks (Thread)" ₹4,000, "Any item") |
| M5 | Link historical visits to customers | set `Visit.customerId` by contact |

---

## 21. Edge cases (must have tests)

| # | Case | Expected |
|---|---|---|
| E1 | Two customers confirm the same slot at the same moment | One succeeds; the other gets `SLOT_TAKEN` + alternatives |
| E2 | Walk-in logged for an artist with an online booking at that time | Walk-in creation fails with clear message; staff may force (audited) and must move one |
| E3 | Payment captured after hold expired, slot still free | Booking confirmed |
| E4 | Payment captured after hold expired, slot taken | Cancelled by system, owner alerted, refund queued |
| E5 | Webhook arrives twice / browser verify after webhook | No duplicate state change |
| E6 | Owner changes price after booking | Booking keeps snapshot price |
| E7 | Owner deactivates a service with future bookings | Hidden from site; existing bookings honoured; owner warned with list |
| E8 | Artist leave added over confirmed bookings | Leave saved; conflicting bookings flagged on board + Telegram; staff reassigns or cancels |
| E9 | Booking spans closing time | Not offered |
| E10 | Customer books at 23:50 IST for tomorrow morning | Lead time respected; request SLA starts at opening |
| E11 | Same phone tries 4th active booking | `LIMIT_REACHED` |
| E12 | Same phone books overlapping times | Rejected |
| E13 | Group booking, one guest can't be placed | Whole slot not offered |
| E14 | Colour without patch test | Earliest slot ≥ 48h, message shown |
| E15 | Customer adds services at desk | Billed normally; artist time extended if free |
| E16 | Deposit larger than final bill | Difference refunded and recorded |
| E17 | Promo at max uses during concurrent bookings | Conditional `$inc` lets only allowed number through |
| E18 | Package daily cap on Karva Chauth | Same as E17, per day |
| E19 | TTL lag leaves an expired hold in place | Create TXN deletes expired holds before inserting |
| E20 | Server clock UTC vs IST around midnight | Tests run at 18:29 UTC and 18:31 UTC (≈ midnight IST) |
| E21 | WhatsApp send fails | Booking still succeeds; logged; retried by cron once |
| E22 | Customer without smartphone | Front desk books by phone with the same engine |
| E23 | Holiday added after bookings exist on that date | Owner warned with list before saving |
| E24 | Refund API fails | Stays in refund queue; owner alerted; no silent loss |

---

## 22. Environment variables (backend additions)

`PUBLIC_TOKEN_SECRET` · `TURNSTILE_SECRET_KEY` · `WATI_API_URL` · `WATI_API_TOKEN` ·
`WATI_TEMPLATE_*` · `CRON_SECRET` · `REVALIDATE_SECRET` · `CUSTOMER_SITE_URL` ·
`INSTAGRAM_ACCESS_TOKEN` (stored in DB after first refresh) · `GOOGLE_PLACES_API_KEY` ·
`SALON_PLACE_ID`.

Customer site: `NEXT_PUBLIC_API_BASE` · `NEXT_PUBLIC_TURNSTILE_SITE_KEY` ·
`NEXT_PUBLIC_RAZORPAY_KEY_ID` · `REVALIDATE_SECRET`.

---

## 23. What stays unchanged

- Staff login gate (Telegram approval, trusted devices).
- Visit Entry and payment-first flow (extended, not replaced).
- Analytics, Data Pipeline, artist dashboards (they read Visits, which keep the same shape).
- Razorpay webhook endpoint (extended matching only).

---

## 24. Decisions and open questions

### Decisions
| ID | Decision | Why |
|---|---|---|
| D1 | Customer site lives in this repo as `customer/` | Backend changes and site changes ship together; one source of truth |
| D2 | Next.js for the customer site; staff app moves to `app.thexpertshair.com` | SEO, speed from ads, server rendering |
| D3 | Per-service `publicPrice`; online-origin visits bill at public price with list price snapshot | Honest prices online without breaking desk billing |
| D4 | `SlotLock` unique index + transaction prevents double booking | Correct under concurrency on serverless |
| D5 | Walk-ins are Appointments (`channel=walkin`) | One timeline, one lock system |
| D6 | Request bookings pay the deposit upfront, refunded if declined | One payment path; filters non-serious requests |
| D7 | OTP over WhatsApp (Wati) until MSG91 DLT clears | SMS fallback is not available yet |
| D8 | Variants = existing services grouped by `variantGroup` | Visits and analytics stay unchanged |
| D9 | One artist per item; a guest's items chain back-to-back; group guests run in parallel | Covers "cut + threading" combos without colour processing complexity |
| D10 | Instagram via API sync, not iframe embeds | Speed and design control |

### Open questions (owner)
| ID | Question | Default if no answer |
|---|---|---|
| Q1 | Move the whole catalogue to real prices and stop the 50% desk discount? | Keep list + 50% at desk; online uses `publicPrice` |
| Q2 | Deposit amounts per service (chemical, bridal) | ₹500 chemical/bridal, ₹200 peak days |
| Q3 | Cancellation cutoff 24h and late-cancel forfeit OK? | Yes |
| Q4 | Which artists are bookable online and their `onlineShare` | Women's team 100%, barbers 0% for first 2 weeks |
| Q5 | Shared resources (facial bed, pedicure station, makeup chair) and counts | None modelled until answered |
| Q6 | Opening hours, weekly off, festive extended hours | 09:00–20:00 daily |
| Q7 | Instagram account type (Business/Creator?) | Manual reel upload until confirmed |
| Q8 | Wati plan supports authentication templates? | Request Wati upgrade |
| Q9 | Vercel plan (cron frequency) | Assume Pro |
| Q10 | Gift card validity and allowed amounts | 12 months; ₹1k/2k/3k/5k + custom |
